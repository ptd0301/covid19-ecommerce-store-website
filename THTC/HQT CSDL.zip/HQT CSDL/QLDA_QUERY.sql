use QLDA;

select * from NHANVIEN;

select * from NHANVIEN 
where PHG = 4;

select HONV, TENNV from NHANVIEN
where DCHI like N'%HCM%';