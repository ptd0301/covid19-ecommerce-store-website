﻿begin try
	begin tran
		--content
		IF (@TEN_SP_MOI IN (SELECT SP.TEN_SP
								FROM SAN_PHAM SP))
		THROW 52000,  N'Tên sản phẩm trùng với tên sản phẩm có trong danh sách', 1
	commit tran
	end try
begin catch
	declare @ErrorMessage nvarchar(4000), @ErrorSeverity int, @ErrorState int;
select @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
raiserror (@ErrorMessage, @ErrorSeverity, @ErrorState);
if (@@TRANCOUNT > 0)
	rollback tran
end catch
go

CREATE OR ALTER
PROC USP_UPDATE_TEN_SP
@TEN_SP_CU NVARCHAR(50), @TEN_SP_MOI NVARCHAR(50)
as begin
begin try
		begin tran
			UPDATE SAN_PHAM
		SET SAN_PHAM.TEN_SP = @TEN_SP_MOI
		WHERE SAN_PHAM.TEN_SP = @TEN_SP_CU

		WAITFOR DELAY '0:0:10'

		IF (@TEN_SP_MOI IN (SELECT SP.TEN_SP
								FROM SAN_PHAM SP))
		THROW 52000,  N'Tên sản phẩm trùng với tên sản phẩm có trong danh sách', 1
		commit tran
	end try
	begin catch
		declare @ErrorMessage nvarchar(4000), @ErrorSeverity int, @ErrorState int;
    select @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
    raiserror (@ErrorMessage, @ErrorSeverity, @ErrorState);
	if (@@TRANCOUNT > 0)
		rollback tran
	end catch
end