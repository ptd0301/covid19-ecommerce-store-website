﻿USE DATHANGONLINE
GO

--INSERT TABLE TAI_KHOAN
insert dbo.TAI_KHOAN
values ('TK000001', 'admin1', 'admin1', N'admin', 'admin@gmail.com', '0365314569', N'TP. Hồ Chí Minh', N'Quận 1', N'Phường 7', N'Đường A', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000002', 'tkdoitac1', 'mkdoitac1', N'Đối tác', 'Doitac1@gmail.com', '0365471756', N'TP. Hồ Chí Minh', N'Quận 7', N'Phường 5', N'Đường B1', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000003', 'tkdoitac2', 'mkdoitac2', N'Đối tác', 'Doitac2@gmail.com', '0365471742', N'Cần Thơ', N'Quận 8', N'Phường 1', N'Đường B2', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000004', 'tkdoitac3', 'mkdoitac3', N'Đối tác', 'Doitac3@gmail.com', '0365471478', N'Đà nẵng', N'Quận 5', N'Phường 3', N'Đường B3', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000005', 'tkdoitac4', 'mkdoitac4', N'Đối tác', 'Doitac4@gmail.com', '0365470278', N'TP. Hồ Chí Minh', N'Quận 2', N'Phường 8', N'Đường B4', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000006', 'tkdoitac5', 'mkdoitac5', N'Đối tác', 'Doitac5@gmail.com', '0365473640', N'Hải Phòng', N'Quận 7', N'Phường 4', N'Đường B5', N'Đã khóa')
insert dbo.TAI_KHOAN
values ('TK000007', 'tkkhachhang1', 'mkkhachhang1', N'Khách hàng', 'Khachhang1@gmail.com', '0906789214', N'Cần Thơ', N'Quận 2', N'Phường 5', N'Đường C1', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000008', 'tkkhachhang2', 'mkkhachhang2', N'Khách hàng', 'Khachhang2@gmail.com', '0906787564', N'TP. Hồ Chí Minh', N'Quận 6', N'Phường 6', N'Đường C2', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000009', 'tkkhachhang3', 'mkkhachhang3', N'Khách hàng', 'Khachhang3@gmail.com', '0906783201', N'Cần Thơ', N'Quận 5', N'Phường 7', N'Đường C3', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000010', 'tkkhachhang4', 'mkkhachhang4', N'Khách hàng', 'Khachhang4@gmail.com', '0906785014', N'Hà Nội', N'Quận 3', N'Phường 2', N'Đường C4', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000011', 'tkkhachhang5', 'mkkhachhang5', N'Khách hàng', 'Khachhang5@gmail.com', '0906780407', N'Hải Phòng', N'Quận 9', N'Phường 5', N'Đường C5', N'Đã khóa')
insert dbo.TAI_KHOAN
values ('TK000012', 'tktaixe1', 'mktaixe1', N'Tài xế', 'Taixe1@gmail.com', '0204657756', N'Hải Phòng', N'Quận 4', N'Phường 5', N'Đường E1', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000013', 'tktaixe2', 'mktaixe2', N'Tài xế', 'Taixe2@gmail.com', '0204654730', N'Đà Nẵng', N'Quận 8', N'Phường 3', N'Đường E2', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000014', 'tktaixe3', 'mktaixe3', N'Tài xế', 'Taixe3@gmail.com', '0204650357', N'Cần Thơ', N'Quận 3', N'Phường 2', N'Đường E3', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000015', 'tktaixe4', 'mktaixe4', N'Tài xế', 'Taixe4@gmail.com', '0204651246', N'Hà Nội', N'Quận 2', N'Phường 1', N'Đường E4', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000016', 'tktaixe5', 'mktaixe5', N'Tài xế', 'Taixe5@gmail.com', '0204657821', N'TP. Hồ Chí Minh', N'Quận 5', N'Phường 6', N'Đường E5', N'Đã khóa')
insert dbo.TAI_KHOAN
values ('TK000017', 'tknhanvien1', 'mknhanvien1', N'Nhân viên', 'Nhanvien1@gmail.com', '0230890467', N'Đà nẵng', N'Quận 9', N'Phường 6', N'Đường D1', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000018', 'tknhanvien2', 'mknhanvien2', N'Nhân viên', 'Nhanvien2@gmail.com', '0230895785', N'TP. Hồ Chí Minh', N'Quận 4', N'Phường 7', N'Đường D2', N'Đã kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000019', 'tknhanvien3', 'mknhanvien3', N'Nhân viên', 'Nhanvien3@gmail.com', '0230896624', N'Hải Phòng', N'Quận 6', N'Phường 1', N'Đường D3', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000020', 'tknhanvien4', 'mknhanvien4', N'Nhân viên', 'Nhanvien4@gmail.com', '0230892404', N'Cần Thơ', N'Quận 2', N'Phường 8', N'Đường D4', N'Chưa kích hoạt')
insert dbo.TAI_KHOAN
values ('TK000021', 'tknhanvien5', 'mknhanvien5', N'Nhân viên', 'Nhanvien5@gmail.com', '0230893640', N'Hà Nội', N'Quận 5', N'Phường 3', N'Đường D5', N'Đã khóa')
--select * from TAI_KHOAN;
--delete dbo.TAI_KHOAN;

----INSERT TABLE KHACH_HANG
insert dbo.KHACH_HANG
values ('KH000001', 'TK000007', N'Nguyễn Văn KHA')
insert dbo.KHACH_HANG
values ('KH000002', 'TK000008', N'Nguyễn Văn KHB')
insert dbo.KHACH_HANG
values ('KH000003', 'TK000009', N'Nguyễn Văn KHC')
insert dbo.KHACH_HANG
values ('KH000004', 'TK000010', N'Nguyễn Văn KHD')
insert dbo.KHACH_HANG
values ('KH000005', 'TK000011', N'Nguyễn Văn KHE')
--select * from KHACH_HANG;
--delete dbo.KHACH_HANG;

----INSERT TABLE TAI_XE
insert dbo.TAI_XE
values ('TX000001', 'TK000012', N'Nguyễn Văn TXA', '079441865021', '16-4P 4106', '107866816570', 50000)
insert dbo.TAI_XE
values ('TX000002', 'TK000013', N'Nguyễn Văn TXB', '079444098021', '45-8T 2578', '107423472589', 50000)
insert dbo.TAI_XE
values ('TX000003', 'TK000014', N'Nguyễn Văn TXC', '023781865021', '65-6D 2037', '425786816570', 50000)
insert dbo.TAI_XE
values ('TX000004', 'TK000015', N'Nguyễn Văn TXD', '079441869804', '40-2R 4298', '107462016570', 50000)
insert dbo.TAI_XE
values ('TX000005', 'TK000016', N'Nguyễn Văn TXE', '079441860371', '57-9A 9641', '107866403058', 50000)
--select * from TAI_XE;
--delete dbo.TAI_XE;

----INSERT TABLE KHU_VUC_HOAT_DONG
insert dbo.KHU_VUC_HOAT_DONG
values ('KV000001', N'TP. Hồ Chí Minh')
insert dbo.KHU_VUC_HOAT_DONG
values ('KV000002', N'Cần Thơ')
insert dbo.KHU_VUC_HOAT_DONG
values ('KV000003', N'Hải Phòng')
insert dbo.KHU_VUC_HOAT_DONG
values ('KV000004', N'Hà Nội')
insert dbo.KHU_VUC_HOAT_DONG
values ('KV000005', N'Tiền Giang')
--select * from KHU_VUC_HOAT_DONG;
----INSERT TABLE HOAT_DONG
insert dbo.HOAT_DONG
values ('TX000001', 'KV000004')
insert dbo.HOAT_DONG
values ('TX000002', 'KV000001')
insert dbo.HOAT_DONG
values ('TX000003', 'KV000005')
insert dbo.HOAT_DONG
values ('TX000004', 'KV000003')
insert dbo.HOAT_DONG
values ('TX000005', 'KV000002')
--select * from HOAT_DONG;
--delete dbo.HOAT_DONG;

----INSERT TABLE LOAI_HANG_HOA
insert dbo.LOAI_HANG_HOA
values ('LH000001', N'Loại hàng A')
insert dbo.LOAI_HANG_HOA
values ('LH000002', N'Loại hàng B')
insert dbo.LOAI_HANG_HOA
values ('LH000003', N'Loại hàng C')
insert dbo.LOAI_HANG_HOA
values ('LH000004', N'Loại hàng D')
insert dbo.LOAI_HANG_HOA
values ('LH000005', N'Loại hàng E')
--select * from LOAI_HANG_HOA;
--delete dbo.LOAI_HANG_HOA;

----INSERT TABLE SAN_PHAM
insert dbo.SAN_PHAM
values ('SP000001', 'LH000002', N'Sản phẩm B1', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000002', 'LH000001', N'Sản phẩm A2', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000003', 'LH000001', N'Sản phẩm A4', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000004', 'LH000003', N'Sản phẩm C2', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000005', 'LH000002', N'Sản phẩm B3', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000006', 'LH000004', N'Sản phẩm D5', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000007', 'LH000005', N'Sản phẩm E1', N'Mô tả')
insert dbo.SAN_PHAM
values ('SP000008', 'LH000004', N'Sản phẩm D4', N'Mô tả')
--select * from SAN_PHAM;
--delete dbo.SAN_PHAM;

----INSERT TABLE DOI_TAC
insert dbo.DOI_TAC
values ('DT000001', 'TK000002', 'LH000001', N'Đối tác A', N'Người đại diện A', N'TP. Hồ Chí Minh', N'Quận 7', 6, 800)
insert dbo.DOI_TAC
values ('DT000002', 'TK000003', 'LH000001', N'Đối tác B', N'Người đại diện B', N'Cần Thơ', N'Quận 8', 4, 600)
insert dbo.DOI_TAC
values ('DT000003', 'TK000004', 'LH000004', N'Đối tác C', N'Người đại diện C', N'Đà Nẵng', N'Quận 5', 4, 400)
insert dbo.DOI_TAC
values ('DT000004', 'TK000005', 'LH000005', N'Đối tác D', N'Người đại diện D', N'TP. Hồ Chí Minh', N'Quận 2', 5, 600)
insert dbo.DOI_TAC
values ('DT000005', 'TK000006', 'LH000002', N'Đối tác E', N'Người đại diện E', N'Hải Phòng', N'Quận 7', 3, 400)
--select * from DOI_TAC;
--delete dbo.DOI_TAC;

----INSERT TABLE HOP_DONG
insert dbo.HOP_DONG
values ('HD000001', 'DT000001', '8100234519', '20210419', '20211019', 0.15, 4)
insert dbo.HOP_DONG
values ('HD000002', 'DT000004', '4286234519', '20210222', '20210822', 0.18, 2)
insert dbo.HOP_DONG
values ('HD000003', 'DT000002', '3145714519', '20210105', '20210705', 0.08, 4)
insert dbo.HOP_DONG
values ('HD000004', 'DT000001', '6100232457', '20210319', '20210919', 0.05, 6)
insert dbo.HOP_DONG
values ('HD000005', 'DT000003', '4425834519', '20210515', '20211115', 0.18, 4)
insert dbo.HOP_DONG
values ('HD000006', 'DT000004', '8472334519', '20210203', '20210802', 0.15, 5)
insert dbo.HOP_DONG
values ('HD000007', 'DT000005', '8100245719', '20210609', '20211209', 0.12, 3)
insert dbo.HOP_DONG
values ('HD000008', 'DT000002', '1247234519', '20210328', '20210928', 0.08, 4)
--select * from HOP_DONG;
--delete dbo.HOP_DONG;

----INSERT TABLE DANH_SACH_HD
insert dbo.DANH_SACH_HD
values ('HD000001', 1, '20210419', '20211019')
insert dbo.DANH_SACH_HD
values ('HD000002', 2, '20210222', '20210822')
insert dbo.DANH_SACH_HD
values ('HD000003', 3, '20210105', '20210705')
insert dbo.DANH_SACH_HD
values ('HD000004', 4, '20210319', '20210919')
insert dbo.DANH_SACH_HD
values ('HD000005', 5, '20210515', '20211115')
insert dbo.DANH_SACH_HD
values ('HD000006', 6, '20210203', '20210802')
insert dbo.DANH_SACH_HD
values ('HD000007', 7, '20210609', '20211209')
insert dbo.DANH_SACH_HD
values ('HD000008', 8, '20210328', '20210928')
--select * from DANH_SACH_HD;
--delete dbo.DANH_SACH_HD;

----INSERT TABLE CHI_NHANH
insert dbo.CHI_NHANH
values ('CN000001', 'DT000001', N'TP. Hồ Chí Minh', N'Quận 7', N'Phường 8', N'Đường A1')
insert dbo.CHI_NHANH
values ('CN000002', 'DT000001', N'Cần Thơ', N'Quận 5', N'Phường 10', N'Đường B5')
insert dbo.CHI_NHANH
values ('CN000003', 'DT000001', N'Hà Nội', N'Quận 4', N'Phường 14', N'Đường C4')
insert dbo.CHI_NHANH
values ('CN000004', 'DT000001', N'Đà Nẵng', N'Quận 9', N'Phường 6', N'Đường E5')
insert dbo.CHI_NHANH
values ('CN000005', 'DT000001', N'TP. Hồ Chí Minh', N'Quận 11', N'Phường 8', N'Đường A3')
insert dbo.CHI_NHANH
values ('CN000006', 'DT000001', N'Hải Phòng', N'Quận 2', N'Phường 5', N'Đường D1')
insert dbo.CHI_NHANH
values ('CN000007', 'DT000002', N'Cần Thơ', N'Quận 10', N'Phường 5', N'Đường B1')
insert dbo.CHI_NHANH
values ('CN000008', 'DT000002', N'TP. Hồ Chí Minh', N'Quận 7', N'Phường 2', N'Đường A2')
insert dbo.CHI_NHANH
values ('CN000009', 'DT000002', N'Hà Nội', N'Quận 9', N'Phường 3', N'Đường C5')
insert dbo.CHI_NHANH
values ('CN000010', 'DT000002', N'Cần Thơ', N'Quận 3', N'Phường 8', N'Đường B4')
insert dbo.CHI_NHANH
values ('CN000011', 'DT000003', N'Hải Phòng', N'Quận 7', N'Phường 6', N'Đường D2')
insert dbo.CHI_NHANH
values ('CN000012', 'DT000003', N'Đà Nẵng', N'Quận 5', N'Phường 12', N'Đường E2')
insert dbo.CHI_NHANH
values ('CN000013', 'DT000003', N'Đà Nẵng', N'Quận 11', N'Phường 2', N'Đường E5')
insert dbo.CHI_NHANH
values ('CN000014', 'DT000003', N'TP. Hồ Chí Minh', N'Quận 7', N'Phường 4', N'Đường A4')
insert dbo.CHI_NHANH
values ('CN000015', 'DT000004', N'TP. Hồ Chí Minh', N'Quận 6', N'Phường 7', N'Đường A3')
insert dbo.CHI_NHANH
values ('CN000016', 'DT000004', N'Hà Nội', N'Quận 4', N'Phường 3', N'Đường C1')
insert dbo.CHI_NHANH
values ('CN000017', 'DT000004', N'Hà Nội', N'Quận 8', N'Phường 11', N'Đường C4')
insert dbo.CHI_NHANH
values ('CN000018', 'DT000004', N'Cần Thơ', N'Quận 5', N'Phường 8', N'Đường B2')
insert dbo.CHI_NHANH
values ('CN000019', 'DT000004', N'Hải Phòng', N'Quận 10', N'Phường 5', N'Đường D2')
insert dbo.CHI_NHANH
values ('CN000020', 'DT000005', N'Hải Phòng', N'Quận 9', N'Phường 5', N'Đường D4')
insert dbo.CHI_NHANH
values ('CN000021', 'DT000005', N'Đà Nẵng', N'Quận 6', N'Phường 14', N'Đường E3')
insert dbo.CHI_NHANH
values ('CN000022', 'DT000005', N'Hải Phòng', N'Quận 2', N'Phường 7', N'Đường D3')
--select * from CHI_NHANH;
--delete dbo.CHI_NHANH;

----INSERT TABLE PHAN_PHOI
insert dbo.PHAN_PHOI
values ('CN000001', 'SP000001', 200, 20000)
insert dbo.PHAN_PHOI
values ('CN000001', 'SP000005', 100, 17000)
insert dbo.PHAN_PHOI
values ('CN000001', 'SP000008', 80, 21000)
insert dbo.PHAN_PHOI
values ('CN000002', 'SP000003', 150, 9000)
insert dbo.PHAN_PHOI
values ('CN000002', 'SP000001', 240, 20000)
insert dbo.PHAN_PHOI
values ('CN000003', 'SP000002', 300, 26000)
insert dbo.PHAN_PHOI
values ('CN000003', 'SP000004', 210, 12000)
insert dbo.PHAN_PHOI
values ('CN000004', 'SP000005', 90, 17000)
insert dbo.PHAN_PHOI
values ('CN000005', 'SP000007', 160, 30000)
insert dbo.PHAN_PHOI
values ('CN000005', 'SP000006', 320, 7000)
insert dbo.PHAN_PHOI
values ('CN000005', 'SP000003', 230, 9000)
insert dbo.PHAN_PHOI
values ('CN000006', 'SP000001', 270, 20000)
insert dbo.PHAN_PHOI
values ('CN000006', 'SP000005', 180, 17000)
insert dbo.PHAN_PHOI
values ('CN000007', 'SP000004', 350, 12000)
insert dbo.PHAN_PHOI
values ('CN000007', 'SP000007', 100, 30000)
insert dbo.PHAN_PHOI
values ('CN000008', 'SP000008', 90, 21000)
insert dbo.PHAN_PHOI
values ('CN000009', 'SP000008', 260, 21000)
insert dbo.PHAN_PHOI
values ('CN000009', 'SP000004', 140, 12000)
insert dbo.PHAN_PHOI
values ('CN000010', 'SP000003', 190, 9000)
insert dbo.PHAN_PHOI
values ('CN000010', 'SP000001', 80, 20000)
insert dbo.PHAN_PHOI
values ('CN000011', 'SP000008', 230, 21000)
insert dbo.PHAN_PHOI
values ('CN000011', 'SP000002', 250, 26000)
insert dbo.PHAN_PHOI
values ('CN000011', 'SP000004', 190, 12000)
insert dbo.PHAN_PHOI
values ('CN000012', 'SP000003', 100, 9000)
insert dbo.PHAN_PHOI
values ('CN000012', 'SP000007', 150, 30000)
insert dbo.PHAN_PHOI
values ('CN000013', 'SP000007', 80, 30000)
insert dbo.PHAN_PHOI
values ('CN000014', 'SP000006', 200, 7000)
insert dbo.PHAN_PHOI
values ('CN000014', 'SP000005', 260, 17000)
insert dbo.PHAN_PHOI
values ('CN000015', 'SP000005', 210, 17000)
insert dbo.PHAN_PHOI
values ('CN000016', 'SP000004', 310, 12000)
insert dbo.PHAN_PHOI
values ('CN000016', 'SP000003', 340, 9000)
insert dbo.PHAN_PHOI
values ('CN000016', 'SP000002', 280, 26000)
insert dbo.PHAN_PHOI
values ('CN000017', 'SP000007', 90, 30000)
insert dbo.PHAN_PHOI
values ('CN000017', 'SP000001', 300, 20000)
insert dbo.PHAN_PHOI
values ('CN000018', 'SP000008', 230, 21000)
insert dbo.PHAN_PHOI
values ('CN000019', 'SP000003', 220, 9000)
insert dbo.PHAN_PHOI
values ('CN000019', 'SP000001', 140, 20000)
insert dbo.PHAN_PHOI
values ('CN000020', 'SP000003', 190, 9000)
insert dbo.PHAN_PHOI
values ('CN000020', 'SP000002', 80, 26000)
insert dbo.PHAN_PHOI
values ('CN000021', 'SP000008', 310, 21000)
insert dbo.PHAN_PHOI
values ('CN000022', 'SP000004', 320, 12000)
insert dbo.PHAN_PHOI
values ('CN000022', 'SP000007', 260, 30000)
insert dbo.PHAN_PHOI
values ('CN000022', 'SP000005', 190, 17000)
--select * from PHAN_PHOI;
--delete dbo.PHAN_PHOI;

----INSERT TABLE DON_HANG
insert dbo.DON_HANG
values ('DH000001', 'KH000001', 'DT000004', null, 'CN000017', N'48B Đường HTA, Quận 6, Phường 14', N'Hà Nội', null, 20000, 10000, null, null, N'Tiền mặt')
insert dbo.DON_HANG
values ('DH000002', 'KH000002', 'DT000003', null, 'CN000013', N'57A Đường KVD, Quận 10, Phường 2', N'TP. Hồ CHí Minh', null, 15000, 5000, null, null, N'Thẻ tín dụng')
insert dbo.DON_HANG
values ('DH000003', 'KH000003', 'DT000001', null, 'CN000002', N'31H Đường BHH, Quận 11, Phường 9', N'TP. Hồ CHí Minh', null, 20000, 10000, null, null, N'Tiền mặt')
insert dbo.DON_HANG
values ('DH000004', 'KH000004', 'DT000001', null, 'CN000005', N'68T Đường NTH, Quận 5, Phường 8', N'Hải Phòng', null, 25000, 10000, null, null, N'Tiền mặt')
insert dbo.DON_HANG
values ('DH000005', 'KH000005', 'DT000005', null, 'CN000021', N'76G Đường TQD, Quận 8, Phường 10', N'Tiền Giang', null, 30000, 5000, null, null, N'Thẻ ghi nợ')
--select * from DON_HANG;
--delete dbo.DON_HANG;
--delete from DON_HANG where DON_HANG.MA_DH = 'DH000013'


----INSERT TABLE TRANG_THAI
insert dbo.TRANG_THAI
values ('DH000001', N'Đang giao hàng', '20220329 21:19:58')
insert dbo.TRANG_THAI
values ('DH000002', N'Đã giao hàng', '20220117 11:27:30')
insert dbo.TRANG_THAI
values ('DH000003', N'Đang giao hàng', '20220325 18:14:38')
insert dbo.TRANG_THAI
values ('DH000004', N'Đang giao hàng', '20220322 09:42:27')
insert dbo.TRANG_THAI
values ('DH000005', N'Đã xác nhận', '20220320 16:02:41') 
--select * from TRANG_THAI;
--delete dbo.TRANG_THAI;
----INSERT TABLE CHI_TIET_DH
insert dbo.CHI_TIET_DH
values ('DH000001', 'SP000001', 2, 40000)
insert dbo.CHI_TIET_DH
values ('DH000001', 'SP000003', 2, 18000)
insert dbo.CHI_TIET_DH
values ('DH000001', 'SP000004', 1, 12000)
insert dbo.CHI_TIET_DH
values ('DH000002', 'SP000007', 1, 30000)
insert dbo.CHI_TIET_DH
values ('DH000002', 'SP000006', 1, 7000)
insert dbo.CHI_TIET_DH
values ('DH000003', 'SP000007', 2, 60000)
insert dbo.CHI_TIET_DH
values ('DH000004', 'SP000004', 1, 12000)
insert dbo.CHI_TIET_DH
values ('DH000004', 'SP000003', 2, 18000)
insert dbo.CHI_TIET_DH
values ('DH000004', 'SP000006', 3, 21000)
insert dbo.CHI_TIET_DH
values ('DH000005', 'SP000008', 1, 21000)
insert dbo.CHI_TIET_DH
values ('DH000005', 'SP000006', 2, 14000)
--select * from CHI_TIET_DH;
--delete dbo.CHI_TIET_DH;
--delete from CHI_TIET_DH where CHI_TIET_DH.MA_DH = 'DH000013'

--EXEC USP_THANHTIEN_TONGTIEN 'DH000001'
--EXEC USP_THEM_CHI_TIET_DH 'DH000004', 'CN000005', 'SP000007', 3
--GO
--SELECT * FROM CHI_TIET_DH

--EXEC USP_HUY_DH 'DH000012'